export default {
UrlclassLogin: 'http://112.64.170.158:8190/Service1.svc',/* 测试接口 */
UrlclassData_wash_f: 'http://112.64.170.158:9100/api'
}
