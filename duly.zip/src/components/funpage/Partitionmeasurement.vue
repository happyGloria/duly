<template>
  <div class="outbox">
        <div class="startuseoutbox"><a href="http://112.64.170.158:9095/qiantai/PipeNetWorkProject.html?name=" target="_blank">开始使用</a></div>
    <div class="contentoutbox">
      <div class="contentinbox">
        <!-- conten1 -->
        <div class="contentoutbox_contentbox1">
                    供水管网压力监测点优化布置</div>
        <!-- conten2 -->
        <div class="contentoutbox_contentbox2">
          <div class="contentoutbox_contentbox2_title">概述</div>
          <div class="contentoutbox_contentbox2_textbox">
            <div
              class="contentoutbox_contentbox2_text"
            >供水管网压力监测点优化布置工具的主要功能为：评估现有管网压力监测点的监测率、针对监测盲区优化布置新增监测点。适用于水司、设计院等给水管网专业人员。</div>
          </div>
           <div class="contentoutbox_contentbox2_img">
              <img src="../../assets/img/tools_01_01.jpg" alt>
            </div>
        </div>
        <!-- content3 -->
        <div class="contentoutbox_contentbox3">
          <div class="contentoutbox_contentbox3_title">浏览器兼容</div>
          <div class="contentoutbox_contentbox3_textbox">
            <div
              class="contentoutbox_contentbox3_text"
            >供水管网压力监测点优化布置工具兼容主流浏览器，如：Chrome浏览器（推荐）、IE8及以上版本、火狐浏览器、360浏览器、Opera浏览器、搜狗浏览器等。</div>
          </div>
        </div>
        <!-- content4 -->
        <div class="contentoutbox_contentbox4">
          <div class="contentoutbox_contentbox4_title">使用教程</div>
          <!-- outbox_one-->
          <div class="outbox_one">
            <div class="outbox_one1">1、登入</div>
            <div class="outbox_one2">点击右上角【开始使用】若未登录，请先登入</div>
            <div class="outbox_one3">
              <img src="../../assets/img/img1_1.png" alt>
            </div>
            <div class="outbox_one4">
              <img src="../../assets/img/img1_2.png" alt>
            </div>
            <div class="outbox_one5">图1 登入界面</div>
            <div class="outbox_one6">如没有注册用户名，请先注册。</div>
            <div class="outbox_one7">
              <img src="../../assets/img/img1_3.png" alt>
            </div>
            <div class="outbox_one8">图2 注册界面</div>
            <div class="outbox_one9">登录之后的界面，如下图：</div>
            <div class="outbox_one10">
              <img src="../../assets/img/img3.png" alt>
            </div>
            <div class="outbox_one11">图3 方案列表</div>
          </div>
        </div>
        <!-- outbox_two-->
        <div class="outbox_two">
          <div class="outbox_two1">2、创建方案</div>
          <div class="outbox_two2">新建模型方案和删除模型方案按钮能够对模型方案进行增加和删除管理。</div>
          <div class="outbox_two3">
            <!--  <img src="../../assets/img/img1_1.png" alt> -->
          </div>
          <div class="outbox_two4">
            <img src="../../assets/img/img4.png" alt>
          </div>
          <div class="outbox_two5">图4 新建/删除方案</div>
            <div class="outbox_two2">点击新建模型方案，弹出方案创建对话框（图5）。方案名称，用户依据习惯自行命名；上传文件，模型文件，格式为.inp；现有监测点，当前管网现有监测点文件（内容格式如图4），格式为.xlsx。点击创建按钮，完成方案创建。管网现有监测点文件数据为监测点对应的节点ID，数据放置在A列中。</div>
          <div class="outbox_two6">
            <!-- 如没有注册用户名，请先注册。 -->
          </div>
          <div class="outbox_two7">
            <img src="../../assets/img/img5.png" alt>
          </div>
          <div class="outbox_two8">图5 管网现有监测点文件数据</div>
          <div class="outbox_two9">
            <!-- 登录之后的界面，如下图： -->
          </div>
              <div class="outbox_two10">
            <img src="../../assets/img/img6.png" alt>
          </div>
          <div class="outbox_two11">图6 方案创建</div>
           <div class="outbox_two2">点击新建模型方案，弹出方案创建对话框（图5）。方案名称，用户依据习惯自行命名；上传文件，模型文件，格式为.inp；现有监测点，当前管网现有监测点文件（内容格式如图4），格式为.xlsx。点击创建按钮，完成方案创建。管网现有监测点文件数据为监测点对应的节点ID，数据放置在A列中。</div>
          <div class="outbox_two10">
            <img src="../../assets/img/img7.png" alt>
          </div>
          <div class="outbox_two11">图7 上传文件</div>
          <div class="outbox_one10">
              <img src="../../assets/img/img3.png" alt>
            </div>
            <div class="outbox_one11">图8 添加多个模型方案之后</div>
        </div>
        <!-- outbox_three-->
        <div class="outbox_three">
          <div class="outbox_three1">3、方案评估计算</div>
          <div class="outbox_three2">点击创建方案的打开按钮，进入压力监测点评估优化布置界面。左侧为管网的基本信息和评估参数，右侧为管网评估优化的专题图。</div>
          <div class="outbox_three3">
            <!--  <img src="../../assets/img/img1_1.png" alt> -->
          </div>
          <div class="outbox_three4">
            <img style="width:100%;height:100%" src="../../assets/img/img20.png" alt>
          </div>
          <div class="outbox_three5">图9 压力监测点评估优化布置界面</div>
            <div class="outbox_three2">基础管网数据，包含模型节点总数、管道总数、现有压力监测点的个数；现状评估，根据模型计算得出的默认参数评估当前现有监测点的监测率和覆盖范围。计算方案列表，用户依据不同的条件制定不同的方案，可将两个方案进行对比，综合评价找出最佳优化布置方案。初始分区展示出管网模型的独立区域，展示出各个区域的节点总数、管道总长度和监测点个数；现状评估展示出管网当前监测点的监测范围和监测率。监测点备选区域，生成新方案时，展示出可以安装监测点的区域和不能安装监测点的区域；计算覆盖，生成方案时，展示出新增监测点后模型监测区的变化及单个监测点的监测区域；计算分区，生成方案时，依照管网拓扑进行分区，优化布置监测点时保证每个区都有监测点，提高监测点布置的均匀性。 在现状评估模块中，用户针对当前方案可以新增、删除监测点。用户也可以自定义监测点的精度，即为在发生漏失事件时，在一定的水量下，能够引起几个压力监测点变化以及压力变化的最小值。工具会依据模型规模自动给出默认值，用户也可自行修改。之后再重新进行评估计算</div>
               <div class="outbox_three4" style="border:none">
            <img src="../../assets/img/img9.png" alt>
          </div>
          <div class="outbox_three5">图10 压力监测点评估优化布置界面</div>
            <div class="outbox_three4" style="border:none">
            <img src="../../assets/img/img10.png" alt>
          </div>
          <div class="outbox_three5">图11 压力监测点评估优化布置界面</div>
        </div>
 <!-- outbox_four-->
        <div class="outbox_four">
          <div class="outbox_four1">4、计算方案列表模块</div>
          <div class="outbox_four2">在计算方案列表模块中，用户可以对计算方案进行添加、删除、对比、设置、计算和导出等操作。不同参数建立不同的方案，通过不同方案的对比分析确定最佳布置方案。</div>
          <div class="outbox_four3">
            <!--  <img src="../../assets/img/img1_1.png" alt> -->
          </div>
          <div class="outbox_four4" style="border:none;height:100%">
            <img src="../../assets/img/img11.png" alt>
          </div>
          <div class="outbox_four5">图12 计算方案列表</div>
        
        </div>
        <!-- 4.1、新增 -->
         <div class="outbox_four">
          <div class="outbox_four1">4.1、新增</div>
          <div class="outbox_four2">点击添加图标，弹出添加对话框，在对话框中用户可以输入希望添加的监测点个数，高级设置中用户可以对监测点的精度进行修改。</div>
          <div class="outbox_four3">
            <!--  <img src="../../assets/img/img1_1.png" alt> -->
          </div>
          <div class="outbox_four4" style="border:none;height:100%">
            <img src="../../assets/img/img12.png" alt>
          </div>
          <div class="outbox_four5">图13 计算方案创建</div>
          <div class="outbox_four6">
            <!-- 如没有注册用户名，请先注册。 -->
          </div>
          <div class="outbox_four7" style="border:none;height:100%">
            <img  src="../../assets/img/img13.png" alt>
          </div>
          <div class="outbox_four8">图14 参数高级设置</div>
         
        </div>
             <!-- 4.2、新增 -->
         <div class="outbox_four">
          <div class="outbox_four1">4.2、删除</div>
          <div class="outbox_four2">点击删除图标，可以删除勾选的计算方案。</div>
         
        </div>
            <!-- 4.3、新增 -->
         <div class="outbox_four">
          <div class="outbox_four1">4.3、对比</div>
          <div class="outbox_four2">选择两个方案，点击对比按钮，进入方案对比窗口。用户通过方案对比分析，确定最佳的布置方案。</div>
          <div class="outbox_four3">
            <!--  <img src="../../assets/img/img1_1.png" alt> -->
          </div>
          <div class="outbox_four4" style="border:none;height:100%">
            <img src="../../assets/img/img14.png" alt>
          </div>
          <div class="outbox_four5">图15 计算方案列表</div>
          <div class="outbox_four6">
            <!-- 如没有注册用户名，请先注册。 -->
          </div>
          <div class="outbox_four7" style="border:none;height:100%">
            <img style="width:100%;height:100%" src="../../assets/img/img15.png" alt>
          </div>
          <div class="outbox_four8">图16 计算方案对比图</div>
         
        </div>
           <!-- 4.4、新增 -->
         <div class="outbox_four">
          <div class="outbox_four1">4.4、设置</div>
          <div class="outbox_four2">选中一条计算方案参数，点击设置图标，可对计算方案参数进行重新修改，修改成功后会删除之前该方案计算结果。</div>
          <div class="outbox_four3">
            <!--  <img src="../../assets/img/img1_1.png" alt> -->
          </div>
          <div class="outbox_four4" style="border:none;height:100%">
            <img src="../../assets/img/img16.png" alt>
          </div>
          <div class="outbox_four5">图17 计算方案参数设置</div>
         
         
        </div>
            <!-- 4.5、新增 -->
         <div class="outbox_four">
          <div class="outbox_four1">4.5、计算</div>
          <div class="outbox_four2">选中一条计算方案参数，点击计算图标，对该参数方案进行计算，稍等片刻后，返回计算结果，右侧展示计算返回的专题图。</div>
          <div class="outbox_four3">
            <!--  <img src="../../assets/img/img1_1.png" alt> -->
          </div>
          <div class="outbox_four4" style="border:none;height:100%">
            <img style="width:100%;height:100%" src="../../assets/img/img17.png" alt>
          </div>
          <div class="outbox_four5">图18 计算覆盖范围图</div>
          <div class="outbox_four6">
            <!-- 如没有注册用户名，请先注册。 -->
          </div>
          <div class="outbox_four7" style="border:none;height:100%">
            <img style="width:100%;height:100%" src="../../assets/img/img18.png" alt>
          </div>
          <div class="outbox_four8">图19 计算分区图</div>
         
        </div>
           <!-- 4.6、新增 -->
         <div class="outbox_four">
          <div class="outbox_four1">4.6、导出</div>
          <div class="outbox_four2">点击导出图标，等待工具自动生成方案报告，选择保存路径完成保存。</div>
          <div class="outbox_four3">
            <!--  <img src="../../assets/img/img1_1.png" alt> -->
          </div>
          <div class="outbox_four4" style="border:none;height:100%">
            <img src="../../assets/img/img19.png" alt>
          </div>
          <div class="outbox_four5">图20 计算覆盖范围图</div>   
        </div>
 <!-- outbox_five-->
        <div class="outbox_five">
          <div class="outbox_five1">5、计算结果分析</div>
          <div class="outbox_five2">选择计算方案列表中一个方案，在计算结果分析中展示监测率随监测个数的变化图表。</div>
          <div class="outbox_five3">
            <!--  <img src="../../assets/img/img1_1.png" alt> -->
          </div>
          <div class="outbox_five4">
            <img src="../../assets/img/img1901.png" alt>
          </div>
          <div class="outbox_five5" style="margin-bottom:500px">图21 计算覆盖范围图</div>
         
        </div>

        <!-- content结束 -->
      </div>
    </div>
  </div>
</template>
<script>
export default {
  name: "Partitionmeasurement"
};
</script>
<style scoped>
.outbox {
  width: 100%;
  height: 100vh;
  overflow: auto;
  position: relative;
}
.startuseoutbox {
  width: 120px;
  height: 40px;
  background: #349df0;
  line-height: 40px;
  color: #ffffff;
  font-size: 16px;
  text-align: center;
  position: absolute;
  right: 40px;
  top: 40px;
  cursor: pointer;
}
.startuseoutbox:hover a {
  color: #0073eb;
}
a{
  text-decoration: none;
  color: #ffffff;
}
.contentoutbox {
  /*  display: flex;
  flex-direction: row;
  flex-wrap: nowrap;
  justify-content: flex-end; */
  width: 100%;
  /*   background-color: rgb(9, 255, 0); */
}
.contentinbox {
  width: 58%;
  margin-left: 60px;
}
/* content1 */
.contentoutbox_contentbox1 {
  width: 100%;
  height: 124px;
  font-size: 36px;
  font-weight: 100;
  color: #383a3c;
  line-height: 124px;
  /*   background-color: aqua; */
}
/* content2 */
.contentoutbox_contentbox2 {
  display: flex;
  flex-direction: column;
  flex-wrap: nowrap;
  align-items: flex-start;
  width: 100%;
 /*  height: 220px; */
  /* background-color: aqua; */
}
.contentoutbox_contentbox2_title {
  width: 100%;
  height: 40px;
  font-size: 24px;
  color: #383a3c;
  line-height: 40px;
  font-weight: 100;
  /*  background-color: rgb(123, 255, 0); */
}
.contentoutbox_contentbox2_textbox {
  width: 100%;
  height: 60px;
  margin-top: 20px;

  /*   background-color: rgb(0, 255, 115); */
}
.contentoutbox_contentbox2_img{
     border: 1px solid #d6d9dd;
  margin-top: 40px;
  margin-bottom: 80px
}
.contentoutbox_contentbox2_text {
  width: 100%;
  height: 45px;
  line-height: 24px;
  letter-spacing: 1;
  color: #74777c;
  background: none;
  font-size: 14px;
  /*   background-color: rgb(76, 0, 255); */
}
/* content3 */
.contentoutbox_contentbox3 {
  display: flex;
  flex-direction: column;
  flex-wrap: nowrap;
  align-items: flex-start;
  width: 100%;
  height: 180px;
  /*   background-color: aqua; */
}
.contentoutbox_contentbox3_title {
  width: 100%;
  height: 40px;
  font-size: 24px;
  color: #383a3c;
  line-height: 40px;
  font-weight: 100;
  /*  background-color: rgb(123, 255, 0); */
}
.contentoutbox_contentbox3_textbox {
  width: 100%;
  height: 60px;
  margin-top: 20px;
  /*   background-color: rgb(0, 255, 115); */
}
.contentoutbox_contentbox3_text {
  width: 100%;
  height: 45px;
  line-height: 24px;
  letter-spacing: 1;
  color: #74777c;
  background: none;
  font-size: 14px;
  /*   background-color: rgb(76, 0, 255); */
}
/* content4 */
.contentoutbox_contentbox4 {
  display: flex;
  flex-direction: column;
  flex-wrap: nowrap;
  align-items: flex-start;
  width: 100%;
  /* height: 220px; */
  /* background-color: aqua; */
}
.contentoutbox_contentbox4_title {
  width: 100%;
  height: 40px;
  font-size: 24px;
  color: #383a3c;
  line-height: 40px;
  font-weight: 100;
  /*  background-color: rgb(123, 255, 0); */
}
/* one */
.outbox_one {
  margin-top: 50px;
}
.outbox_one1 {
  font-size: 16px;
  font-weight: bold;
  color: #383a3c;
}
.outbox_one2 {
  line-height: 24px;
  letter-spacing: 1;
  color: #74777c;
  background: none;
  font-size: 14px;
  margin-top: 30px;
}
.outbox_one3 {
  margin-top: 30px;
}
.outbox_one4 {
  margin-top: -20px;
}
.outbox_one5 {
  margin-top: 10px;
  line-height: 24px;
  letter-spacing: 1;
  color: #b1b6bf;
  font-size: 14px;
  margin-left: 40px;
}
.outbox_one6 {
  margin-top: 50px;
  line-height: 24px;
  letter-spacing: 1;
  color: #74777c;
  font-size: 14px;
  margin-left: 5px;
}
.outbox_one7 {
  margin-top: 50px;
}
.outbox_one8 {
  margin-top: 10px;
  line-height: 24px;
  letter-spacing: 1;
  color: #b1b6bf;
  font-size: 14px;
  margin-left: 40px;
}
.outbox_one9 {
  margin-top: 30px;
  line-height: 24px;
  letter-spacing: 1;
  color: #74777c;
  font-size: 14px;
  margin-left: 5px;
}
.outbox_one10 {
  margin-top: 30px;
}
.outbox_one11 {
  margin-top: 10px;
  line-height: 24px;
  letter-spacing: 1;
  color: #b1b6bf;
  font-size: 14px;
  margin-left: 40px;
}

/* two */
.outbox_two {
  margin-top: 50px;
}
.outbox_two1 {
  font-size: 16px;
  font-weight: bold;
  color: #383a3c;
}
.outbox_two2 {
  line-height: 24px;
  letter-spacing: 1;
  color: #74777c;
  background: none;
  font-size: 14px;
  margin-top: 30px;
}
.outbox_two3 {
  margin-top: 30px;
}
.outbox_two4 {
  margin-top: 30px;
}
.outbox_two5 {
  margin-top: 10px;
  line-height: 24px;
  letter-spacing: 1;
  color: #b1b6bf;
  font-size: 14px;
  margin-left: 40px;
}
.outbox_two6 {
  margin-top: 50px;
  line-height: 24px;
  letter-spacing: 1;
  color: #74777c;
  font-size: 14px;
  margin-left: 5px;
}
.outbox_two7 {
  margin-top: 50px;
}
.outbox_two8 {
  margin-top: 10px;
  line-height: 24px;
  letter-spacing: 1;
  color: #b1b6bf;
  font-size: 14px;
  margin-left: 40px;
}
.outbox_two9 {
  margin-top: 30px;
  line-height: 24px;
  letter-spacing: 1;
  color: #74777c;
  font-size: 14px;
  margin-left: 5px;
}
.outbox_two10 {
  margin-top: 30px;
}
.outbox_two11 {
  margin-top: 10px;
  line-height: 24px;
  letter-spacing: 1;
  color: #b1b6bf;
  font-size: 14px;
  margin-left: 40px;
}

/* three */
.outbox_three {
  margin-top: 50px;
}
.outbox_three1 {
  font-size: 16px;
  font-weight: bold;
  color: #383a3c;
}
.outbox_three2 {
  line-height: 24px;
  letter-spacing: 1;
  color: #74777c;
  background: none;
  font-size: 14px;
  margin-top: 30px;
}
.outbox_three3 {
  margin-top: 30px;
}
.outbox_three4 {
 /*  width: 50%;
  height: 100%; */
  border: 1px solid #d6d9dd;
  margin-top: 30px;
}
.outbox_three5 {
  margin-top: 10px;
  line-height: 24px;
  letter-spacing: 1;
  color: #b1b6bf;
  font-size: 14px;
  margin-left: 40px;
}

/* four */

.outbox_four {
  margin-top: 50px;
}
.outbox_four1 {
  font-size: 16px;
  font-weight: bold;
  color: #383a3c;
}
.outbox_four2 {
  line-height: 24px;
  letter-spacing: 1;
  color: #74777c;
  background: none;
  font-size: 14px;
  margin-top: 30px;
}
.outbox_four3 {
  margin-top: 30px;
}
.outbox_four4 {
  width: 625px;
  height: 296px;
  border: 1px solid #d6d9dd;
  margin-top: 30px;
}
.outbox_four5 {
  margin-top: 10px;
  line-height: 24px;
  letter-spacing: 1;
  color: #b1b6bf;
  font-size: 14px;
  margin-left: 40px;
}
.outbox_four6 {
  margin-top: 50px;
  line-height: 24px;
  letter-spacing: 1;
  color: #74777c;
  font-size: 14px;
  margin-left: 5px;
}
.outbox_four7 {
   width: 895px;
  height: 584px;
  border: 1px solid #d6d9dd;
  margin-top: 50px;
}
.outbox_four8 {
  margin-top: 10px;
  line-height: 24px;
  letter-spacing: 1;
  color: #b1b6bf;
  font-size: 14px;
  margin-left: 40px;
}


/* five */

.outbox_five {
  margin-top: 50px;
}
.outbox_five1 {
  font-size: 16px;
  font-weight: bold;
  color: #383a3c;
}
.outbox_five2 {
  line-height: 24px;
  letter-spacing: 1;
  color: #74777c;
  background: none;
  font-size: 14px;
  margin-top: 30px;
}
.outbox_five3 {
  margin-top: 30px;
}
.outbox_five4 {
  margin-top: 30px;
}
.outbox_five5 {
  margin-top: 10px;
  line-height: 24px;
  letter-spacing: 1;
  color: #b1b6bf;
  font-size: 14px;
  margin-left: 40px;
}
.outbox_five6 {
  margin-top: 50px;
  line-height: 24px;
  letter-spacing: 1;
  color: #74777c;
  font-size: 14px;
  margin-left: 5px;
}
.outbox_five7 {
 /*   width: 895px;
  height: 416px; */
  border: 1px solid #d6d9dd;
  margin-top: 50px;
}
.outbox_five8 {
  margin-top: 10px;
  line-height: 24px;
  letter-spacing: 1;
  color: #b1b6bf;
  font-size: 14px;
  margin-left: 40px;
}


</style>


