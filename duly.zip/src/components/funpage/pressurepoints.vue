<template>
  <div class="outbox">
        <div class="startuseoutbox"><a href="http://112.64.170.158:9095/qiantai/PipeNetWorkProject.html?name=" target="_blank">开始使用</a></div>
    <div class="contentoutbox">
      <div class="contentinbox">
        <!-- conten1 -->
        <div class="contentoutbox_contentbox1">分区计量优化布置</div>
        <!-- conten2 -->
        <div class="contentoutbox_contentbox2">
          <div class="contentoutbox_contentbox2_title">概述</div>
          <div class="contentoutbox_contentbox2_textbox">
            <div
              class="contentoutbox_contentbox2_text"
            >供水管网计量分区评估和优化布置工具能够充分利用水力模型来分析计量分区方案对管网运行压力、流量、水龄等参数的影响，以此来评估优选出最经济、施工便捷的实施方案</div>
          </div>
        </div>
        <!-- content3 -->
        <div class="contentoutbox_contentbox3">
          <div class="contentoutbox_contentbox3_title">浏览器兼容</div>
          <div class="contentoutbox_contentbox3_textbox">
            <div
              class="contentoutbox_contentbox3_text"
            >供水管网压力监测点优化布置工具兼容主流浏览器，如：Chrome浏览器（推荐）、IE8及以上版本、火狐浏览器、360浏览器、Opera浏览器、搜狗浏览器等。</div>
          </div>
        </div>
        <!-- content4 -->
        <div class="contentoutbox_contentbox4">
          <div class="contentoutbox_contentbox4_title">使用教程</div>
          <!-- outbox_one-->
          <div class="outbox_one">
            <div class="outbox_one1">1、登入</div>
            <div class="outbox_one2">点击右上角【开始使用】若未登录，请先登入</div>
            <div class="outbox_one3">
              <img src="../../assets/img/img1_1.png" alt>
            </div>
            <div class="outbox_one4">
              <img src="../../assets/img/img1_2.png" alt>
            </div>
            <div class="outbox_one5">图1 登入界面</div>
            <div class="outbox_one6">如没有注册用户名，请先注册。</div>
            <div class="outbox_one7">
              <img src="../../assets/img/img1_3.png" alt>
            </div>
            <div class="outbox_one8">图2 注册界面</div>
            <div class="outbox_one9">登录之后的界面，如下图：</div>
            <div class="outbox_one10">
              <img src="../../assets/img/img3.png" alt>
            </div>
            <div class="outbox_one11">图3 方案列表</div>
          </div>
        </div>
        <!-- outbox_two-->
        <div class="outbox_two">
          <div class="outbox_two1">2、创建方案</div>
          <div class="outbox_two2">使用工具前，用户需要创建新方案，上传分析管网的INP文件和现有监测点位置信息EXCEL，并命名方案名称，选择分析日期，如图：</div>
          <div class="outbox_two3">
            <!--  <img src="../../assets/img/img1_1.png" alt> -->
          </div>
          <div class="outbox_two4">
            <img src="../../assets/img/img4.png" alt>
          </div>
          <div class="outbox_two5">新建/删除方案</div>
          <div class="outbox_two6">
            <!-- 如没有注册用户名，请先注册。 -->
          </div>
          <div class="outbox_two7">
            <img src="../../assets/img/img5.png" alt>
          </div>
          <div class="outbox_two8">方案创建</div>
          <div class="outbox_two9">
            <!-- 登录之后的界面，如下图： -->
          </div>
          <div class="outbox_two10">
            <img src="../../assets/img/img7.png" alt>
          </div>
          <div class="outbox_two11">添加多个模型方案之后</div>
        </div>
        <!-- outbox_three-->
        <div class="outbox_three">
          <div class="outbox_three1">3、管网基础数据</div>
          <div class="outbox_three2">本产品可对上传的INP文件进行基础数据分析，将统计节点、管道和现有流量监测点个数结果列表在该模块展示（如下图）。</div>
          <div class="outbox_three3">
            <!--  <img src="../../assets/img/img1_1.png" alt> -->
          </div>
          <div class="outbox_three4">
            <img src="../../assets/img/img_zone_2.png" alt>
          </div>
          <div class="outbox_three5">管网基础数据</div>
        </div>
 <!-- outbox_four-->
        <div class="outbox_four">
          <div class="outbox_four1">4、现状评估</div>
          <div class="outbox_four2">该功能主要实现对现有监测点监测情况进行分析，可在管网地图中按是否能组成独立区域进行绘制。用户也可在管网地图上直接点选新增流量监测点进行定点分析，或删除监测点评估由此对可监控区域带来的影响等情况（如下图）。</div>
          <div class="outbox_four3">
            <!--  <img src="../../assets/img/img1_1.png" alt> -->
          </div>
          <div class="outbox_four4">
            <img src="../../assets/img/img_zone_3.png" alt>
          </div>
          <div class="outbox_four5">管网现状评估</div>
          <div class="outbox_four6">
            <!-- 如没有注册用户名，请先注册。 -->
          </div>
          <div class="outbox_four7">
            <img style=" width: 100%;" src="../../assets/img/img_zone_4.png" alt>
          </div>
          <div class="outbox_four8">管网计量分区现状图</div>
         
        </div>
 <!-- outbox_five-->
        <div class="outbox_five">
          <div class="outbox_five1">5、计算方案列表</div>
          <div class="outbox_five2">新建分区计量方案在该模块中进行分析。用户在参数设置中设定欲分区的数量，允许的偏差百分比参数（偏差百分比为分区结果各区域拓扑规模和设定值得偏差），或保持根据该模型拓扑规模确定的默认值。运算后即可分别查看各区域评估结果，包括区域新增监测点等信息（如下图）。</div>
          <div class="outbox_five3">
            <!--  <img src="../../assets/img/img1_1.png" alt> -->
          </div>
          <div class="outbox_five4">
            <img src="../../assets/img/img_zone_5.png" alt>
          </div>
          <div class="outbox_five5">流量监测点布置参数设置</div>
          <div class="outbox_five6">
            <!-- 如没有注册用户名，请先注册。 -->
          </div>
          <div class="outbox_five7">
            <img style=" width: 100%;" src="../../assets/img/img_zone_6.png" alt>
          </div>
          <div class="outbox_five8">计算方案列表</div>
         <div class="outbox_five7">
            <img style=" width: 100%;" src="../../assets/img/img_zone_7.png" alt>
          </div>
          <div class="outbox_five8">管网分区现状</div>
        </div>
<!-- outbox_six-->
        <div class="outbox_six">
          <div class="outbox_six1">6、计算方案列表</div>
          <div class="outbox_six2">将展示新的计量分区结果。包括各区域的分布情况，区域节点、管道数量、新增监测点、现有监测点在管网中的位置等信息。各数据信息也可导出供用户分析或施工使用。用户可点击查看进行区域预览操作（如下图）。</div>
          <div class="outbox_six3">
            <!--  <img src="../../assets/img/img1_1.png" alt> -->
          </div>
          <div class="outbox_six4">
            <img src="../../assets/img/img_zone_8.png" alt>
          </div>
          <div class="outbox_six5">计算结果分析</div>
          <div class="outbox_six6">
            <!-- 如没有注册用户名，请先注册。 -->
          </div>
          <div class="outbox_six7">
            <img style=" width: 100%;" src="../../assets/img/img_zone_9.png" alt>
          </div>
          <div class="outbox_six8">计算方案1-分区1</div>
       <div class="outbox_six2" style="margin-bottom:500px">实践证明计量分区评估与优化产品是分区计量管网漏失控制的有效途径，根据分区综合性的优化原则从水务企业根本需求出发，帮助企业真正做到节水增益，最终实现制水可持续发展。</div>
        </div>

        <!-- content结束 -->
      </div>
    </div>
  </div>
</template>
<script>
export default {
  name: "pressurepoints"
};
</script>
<style scoped>
.outbox {
  width: 100%;
  height: 100vh;
  overflow: auto;
  position: relative;
}
.startuseoutbox {
  width: 120px;
  height: 40px;
  background: #349df0;
  line-height: 40px;
  color: #ffffff;
  font-size: 16px;
  text-align: center;
  position: absolute;
  right: 40px;
  top: 40px;
  cursor: pointer;
}
.startuseoutbox:hover a {
  color: #0073eb;
}
a{
  text-decoration: none;
  color: #ffffff;
}
.contentoutbox {
  /*  display: flex;
  flex-direction: row;
  flex-wrap: nowrap;
  justify-content: flex-end; */
  width: 100%;
  /*   background-color: rgb(9, 255, 0); */
}
.contentinbox {
  width: 58%;
  margin-left: 60px;
}
/* content1 */
.contentoutbox_contentbox1 {
  width: 100%;
  height: 124px;
  font-size: 36px;
  font-weight: 100;
  color: #383a3c;
  line-height: 124px;
  /*   background-color: aqua; */
}
/* content2 */
.contentoutbox_contentbox2 {
  display: flex;
  flex-direction: column;
  flex-wrap: nowrap;
  align-items: flex-start;
  width: 100%;
  height: 220px;
  /* background-color: aqua; */
}
.contentoutbox_contentbox2_title {
  width: 100%;
  height: 40px;
  font-size: 24px;
  color: #383a3c;
  line-height: 40px;
  font-weight: 100;
  /*  background-color: rgb(123, 255, 0); */
}
.contentoutbox_contentbox2_textbox {
  width: 100%;
  height: 60px;
  margin-top: 20px;
  /*   background-color: rgb(0, 255, 115); */
}
.contentoutbox_contentbox2_text {
  width: 100%;
  height: 45px;
  line-height: 24px;
  letter-spacing: 1;
  color: #74777c;
  background: none;
  font-size: 14px;
  /*   background-color: rgb(76, 0, 255); */
}
/* content3 */
.contentoutbox_contentbox3 {
  display: flex;
  flex-direction: column;
  flex-wrap: nowrap;
  align-items: flex-start;
  width: 100%;
  height: 180px;
  /*   background-color: aqua; */
}
.contentoutbox_contentbox3_title {
  width: 100%;
  height: 40px;
  font-size: 24px;
  color: #383a3c;
  line-height: 40px;
  font-weight: 100;
  /*  background-color: rgb(123, 255, 0); */
}
.contentoutbox_contentbox3_textbox {
  width: 100%;
  height: 60px;
  margin-top: 20px;
  /*   background-color: rgb(0, 255, 115); */
}
.contentoutbox_contentbox3_text {
  width: 100%;
  height: 45px;
  line-height: 24px;
  letter-spacing: 1;
  color: #74777c;
  background: none;
  font-size: 14px;
  /*   background-color: rgb(76, 0, 255); */
}
/* content4 */
.contentoutbox_contentbox4 {
  display: flex;
  flex-direction: column;
  flex-wrap: nowrap;
  align-items: flex-start;
  width: 100%;
  /* height: 220px; */
  /* background-color: aqua; */
}
.contentoutbox_contentbox4_title {
  width: 100%;
  height: 40px;
  font-size: 24px;
  color: #383a3c;
  line-height: 40px;
  font-weight: 100;
  /*  background-color: rgb(123, 255, 0); */
}
/* one */
.outbox_one {
  margin-top: 50px;
}
.outbox_one1 {
  font-size: 16px;
  font-weight: bold;
  color: #383a3c;
}
.outbox_one2 {
  line-height: 24px;
  letter-spacing: 1;
  color: #74777c;
  background: none;
  font-size: 14px;
  margin-top: 30px;
}
.outbox_one3 {
  margin-top: 30px;
}
.outbox_one4 {
  margin-top: -20px;
}
.outbox_one5 {
  margin-top: 10px;
  line-height: 24px;
  letter-spacing: 1;
  color: #b1b6bf;
  font-size: 14px;
  margin-left: 40px;
}
.outbox_one6 {
  margin-top: 50px;
  line-height: 24px;
  letter-spacing: 1;
  color: #74777c;
  font-size: 14px;
  margin-left: 5px;
}
.outbox_one7 {
  margin-top: 50px;
}
.outbox_one8 {
  margin-top: 10px;
  line-height: 24px;
  letter-spacing: 1;
  color: #b1b6bf;
  font-size: 14px;
  margin-left: 40px;
}
.outbox_one9 {
  margin-top: 30px;
  line-height: 24px;
  letter-spacing: 1;
  color: #74777c;
  font-size: 14px;
  margin-left: 5px;
}
.outbox_one10 {
  margin-top: 30px;
}
.outbox_one11 {
  margin-top: 10px;
  line-height: 24px;
  letter-spacing: 1;
  color: #b1b6bf;
  font-size: 14px;
  margin-left: 40px;
}

/* two */
.outbox_two {
  margin-top: 50px;
}
.outbox_two1 {
  font-size: 16px;
  font-weight: bold;
  color: #383a3c;
}
.outbox_two2 {
  line-height: 24px;
  letter-spacing: 1;
  color: #74777c;
  background: none;
  font-size: 14px;
  margin-top: 30px;
}
.outbox_two3 {
  margin-top: 30px;
}
.outbox_two4 {
  margin-top: 30px;
}
.outbox_two5 {
  margin-top: 10px;
  line-height: 24px;
  letter-spacing: 1;
  color: #b1b6bf;
  font-size: 14px;
  margin-left: 40px;
}
.outbox_two6 {
  margin-top: 50px;
  line-height: 24px;
  letter-spacing: 1;
  color: #74777c;
  font-size: 14px;
  margin-left: 5px;
}
.outbox_two7 {
  margin-top: 50px;
}
.outbox_two8 {
  margin-top: 10px;
  line-height: 24px;
  letter-spacing: 1;
  color: #b1b6bf;
  font-size: 14px;
  margin-left: 40px;
}
.outbox_two9 {
  margin-top: 30px;
  line-height: 24px;
  letter-spacing: 1;
  color: #74777c;
  font-size: 14px;
  margin-left: 5px;
}
.outbox_two10 {
  margin-top: 30px;
}
.outbox_two11 {
  margin-top: 10px;
  line-height: 24px;
  letter-spacing: 1;
  color: #b1b6bf;
  font-size: 14px;
  margin-left: 40px;
}

/* three */
.outbox_three {
  margin-top: 50px;
}
.outbox_three1 {
  font-size: 16px;
  font-weight: bold;
  color: #383a3c;
}
.outbox_three2 {
  line-height: 24px;
  letter-spacing: 1;
  color: #74777c;
  background: none;
  font-size: 14px;
  margin-top: 30px;
}
.outbox_three3 {
  margin-top: 30px;
}
.outbox_three4 {
  width: 526px;
  height: 168px;
  border: 1px solid #d6d9dd;
  margin-top: 30px;
}
.outbox_three5 {
  margin-top: 10px;
  line-height: 24px;
  letter-spacing: 1;
  color: #b1b6bf;
  font-size: 14px;
  margin-left: 40px;
}

/* four */

.outbox_four {
  margin-top: 50px;
}
.outbox_four1 {
  font-size: 16px;
  font-weight: bold;
  color: #383a3c;
}
.outbox_four2 {
  line-height: 24px;
  letter-spacing: 1;
  color: #74777c;
  background: none;
  font-size: 14px;
  margin-top: 30px;
}
.outbox_four3 {
  margin-top: 30px;
}
.outbox_four4 {
  width: 625px;
  height: 296px;
  border: 1px solid #d6d9dd;
  margin-top: 30px;
}
.outbox_four5 {
  margin-top: 10px;
  line-height: 24px;
  letter-spacing: 1;
  color: #b1b6bf;
  font-size: 14px;
  margin-left: 40px;
}
.outbox_four6 {
  margin-top: 50px;
  line-height: 24px;
  letter-spacing: 1;
  color: #74777c;
  font-size: 14px;
  margin-left: 5px;
}
.outbox_four7 {
   width: 895px;
  height: 584px;
  border: 1px solid #d6d9dd;
  margin-top: 50px;
}
.outbox_four8 {
  margin-top: 10px;
  line-height: 24px;
  letter-spacing: 1;
  color: #b1b6bf;
  font-size: 14px;
  margin-left: 40px;
}


/* five */

.outbox_five {
  margin-top: 50px;
}
.outbox_five1 {
  font-size: 16px;
  font-weight: bold;
  color: #383a3c;
}
.outbox_five2 {
  line-height: 24px;
  letter-spacing: 1;
  color: #74777c;
  background: none;
  font-size: 14px;
  margin-top: 30px;
}
.outbox_five3 {
  margin-top: 30px;
}
.outbox_five4 {
  margin-top: 30px;
}
.outbox_five5 {
  margin-top: 10px;
  line-height: 24px;
  letter-spacing: 1;
  color: #b1b6bf;
  font-size: 14px;
  margin-left: 40px;
}
.outbox_five6 {
  margin-top: 50px;
  line-height: 24px;
  letter-spacing: 1;
  color: #74777c;
  font-size: 14px;
  margin-left: 5px;
}
.outbox_five7 {
 /*   width: 895px;
  height: 416px; */
  border: 1px solid #d6d9dd;
  margin-top: 50px;
}
.outbox_five8 {
  margin-top: 10px;
  line-height: 24px;
  letter-spacing: 1;
  color: #b1b6bf;
  font-size: 14px;
  margin-left: 40px;
}

/* six */

.outbox_six {
  margin-top: 50px;
}
.outbox_six1 {
  font-size: 16px;
  font-weight: bold;
  color: #383a3c;
}
.outbox_six2 {
  line-height: 24px;
  letter-spacing: 1;
  color: #74777c;
  background: none;
  font-size: 14px;
  margin-top: 30px;
}
.outbox_six3 {
  margin-top: 30px;
}
.outbox_six4 {
    width: 552px;
  border: 1px solid #d6d9dd;
  margin-top: 30px;
}
.outbox_six5 {
  margin-top: 10px;
  line-height: 24px;
  letter-spacing: 1;
  color: #b1b6bf;
  font-size: 14px;
  margin-left: 40px;
}
.outbox_six6 {
  margin-top: 50px;
  line-height: 24px;
  letter-spacing: 1;
  color: #74777c;
  font-size: 14px;
  margin-left: 5px;
}
.outbox_six7 {
  margin-top: 50px;
    border: 1px solid #d6d9dd;
}
.outbox_six8 {
  margin-top: 10px;
  line-height: 24px;
  letter-spacing: 1;
  color: #b1b6bf;
  font-size: 14px;
  margin-left: 40px;
}
</style>


